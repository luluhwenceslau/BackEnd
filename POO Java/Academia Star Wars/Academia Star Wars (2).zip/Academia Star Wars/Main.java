
import jedi.Jedi;
import jedi.SabreLuz;
import jedi.Forca;
import planeta.Planeta;
import planeta.Academia;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        int TAM = 4;
        Scanner scanner = new Scanner(System.in);
        Jedi j[] = new Jedi[TAM];
        Academia academia[] = new Academia[2];
        Planeta planeta[] = new Planeta[2];
        Forca forca[] = new Forca[4];
        
        for (int i = 0; i < forca.length; i++){
          System.out.println("========Cadastro das Forcas==========");
          System.out.println("Digite a forca[" +(i+1)+"]:");
          String nome = scanner.nextLine();

          this.forca[i] = new Forca(nome);
        }

        for(int i=0; i < planeta.length; i++){
          System.out.println("--------Cadastro do Planeta--------");
          System.out.println("Digite o nome do planeta [" +(i+1) +"]: ");
          String nome = scanner.nextLine();

          System.out.println("informe a galaxia do planeta: ");
          String galaxia = scanner.nextLine();

          System.out.println("Tamanho do planeta: ");
          double tamanho = scanner.nextLine();

          System.out.println("Populacao do planeta: ");
          int populacao = scanner.nextLine();

          planeta[i] = new Planeta(nome, galaxia, tamanho, populacao);
        }

        for (int i = 0; i < academia.length; i++){
          System.out.println("=========Cadastro da Academia=========");
          System.out.println("Local da academia: ");
          String local = scanner.nextLine();

          System.out.println("Tamanho: ");
          int tamanho = scanner.nextLine();

          System.out.println("Lotacao Máxima: ");
          int lotacaoMaxima = scanner.nextLine();

          //mostrar uma lista contendo os planetas para a escolha.


          this.academia[i] = new Academia(local, tamanho, lotacaoMaxima, planeta);
        }

        public void InsertSabreLuz{
          SabreLuz sabre[] = new SabreLuz[TAM];

          
        }
        
      for(int i = 0; i < j.length; i++){  
        System.out.println("--------Cadastro do Jedi--------------");
        //mostra lista com os vetores contendo os sabres cadastrados
        System.out.print("\nEscolha a cor do sabre ["+(i+1)+"] :");
        String cor = scanner.nextLine();

        System.out.println("Diga o nome do Jedi["+(i+1)+"] :");
        String nome = scanner.nextLine();

        System.out.println("Diga o lado do Jedi["+(i+1)+"] :");
        String lado = scanner.nextLine();
        
        //com as forcas ja mostradas, basta escolher a potencia
        System.out.println("Diga a potencia forca do Jedi["+(i+1)+"] :");         
        String forca = scanner.nextLine();

        sabre[i] = new SabreLuz(cor);  
        j[i] = new Jedi(nome, lado, this.forca[i], this.sabre[i]);
    }

    scanner.close();

    for(int i = 0; i < j.length;i++){
      System.out.println(j[i].toString());
   }    
    }    
}