package personagem;
import armas.SabreLuz;
import java.util.ArrayList;
import armas.Habilidade;

public class Jedi extends Ser{
    private int midiChlorian;
    private SabreLuz sabre;
    private ArrayList<Habilidade> habilidade; //criação da array list
    // Habilidade [] habilidade; //composição de habilidade

    //criação da composição
    public Jedi(String nome, Habilidade h1, Habilidade h2){
        this.setNome(nome);
        this.habilidade.add(h1);
        this.habilidade.add(h2);
    }

   /*  public Jedi(String nome, int midiChlorian, int habilidade){
       this.setNome(nome);
       this.setMidiChlorian(midiChlorian);
       this.habilidade = new Habilidade[habilidade];
    } */

    public int getMidiChlorian(){
        return midiChlorian;
    }
    public void setMidiChlorian(int midiChlorian){
        this.midiChlorian = midiChlorian;
    }

    public SabreLuz getSabre(){
        return sabre;
     }
     public void setSabre(SabreLuz sabre){
        this.sabre = sabre;
     } 

     public ArrayList<Habilidade> gHabilidades(){
        return habilidade;
     }
     public void setHabilidade(ArrayList<Habilidade> habilidades){
        this.habilidade = habilidades;
     }

     public String toString(){
        return "\nJedi: " + this.getNome() +
                "\n Habilidades: " + this.getHabilidade().get(0).getTipoForca()+
                "\n Habilidades: " + this.getHabilidade().get(1).getTipoForca();
     }
}