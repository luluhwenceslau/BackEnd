package personagem;
import armas.SabreLuz;
import java.util.ArrayList;

public class Jedi extends Ser{
    private int midiChlorian;
    private SabreLuz sabre;
    private int tipoForca;
    //private ArrayList<Habilidade> habilidade; //criação da array list
    //Habilidade [] habilidade; //composição de habilidade

    //criação da composição
    public Jedi(String nome,int midiChlorian, int tipoForca){
        this.setNome(nome);
        this.setMidiChlorian(midiChlorian);
        this.setTipoForca(tipoForca);
    }

    /*  public Jedi(String nome, int midiChlorian, int habilidade){
       this.setNome(nome);
       this.setMidiChlorian(midiChlorian);
       this.habilidade = new Habilidade[habilidade];
    } */

    public int getMidiChlorian(){
        return midiChlorian;
    }
    public void setMidiChlorian(int midiChlorian){
        this.midiChlorian = midiChlorian;
    }
    public int getTipoForca(){
        return tipoForca;
    }
    public void setTipoForca(int tipoForca){
        this.tipoForca = tipoForca;
    }

    public SabreLuz getSabre(){
        return sabre;
     }
     public void setSabre(SabreLuz sabre){
        this.sabre = sabre;
     } 

     public String toString(){
        return "\nJedi: " + this.getNome() +
                "\n Habilidades: " + this.getMidiChlorian()+
                "\n Habilidades: " + this.getTipoForca();
     }
}