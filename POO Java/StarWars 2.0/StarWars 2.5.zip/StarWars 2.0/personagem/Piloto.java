package personagem;
import veiculo.Nave;

public class Piloto extends Ser{
    private int id;
    Nave [] nave;

    public Piloto(String nome, int id, String nave){
        this.setNome(nome);
        this.setId(id);
        this.nave = new Nave[nave];
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
}