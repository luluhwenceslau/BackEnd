package armas;

public class Habilidade{

    private String tipoForca;

    public String getTipoForca(){
        return tipoForca;
    }
    public void setTipoForca(String tipoForca){
        this.tipoForca = tipoForca;
    }
}